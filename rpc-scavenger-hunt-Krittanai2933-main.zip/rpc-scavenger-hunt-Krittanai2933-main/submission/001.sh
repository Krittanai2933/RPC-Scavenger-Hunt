# What is the hash of block 654,321?
bitcoin-cli getblockhash 654321
